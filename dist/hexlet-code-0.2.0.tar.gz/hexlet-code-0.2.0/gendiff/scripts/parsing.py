import yaml
import json

def parse(filepath):
    if (filepath[:-34] == 'json'):
        result = json.load(open(filepath))
        return result
    else:
        result = yaml.load(open(filepath))
        return result